import re
import random
import argparse
from pathlib import Path
import math

RECOGNIZER = "RECOGNIZER"
BESTPARSE = "BEST-PARSE"
TOTALWEIGHT = "TOTAL-WEIGHT"
ALLPARSE = "ALLPARSE"


class Node(object):
    """Node Object"""

    def __init__(self, elem=-1, weight=0, lchild=None, rchild=None):
        self.elem = elem
        self.weight = weight
        self.lchild = lchild
        self.rchild = rchild

    def Preorder_Traversal(self, root):
        if root is None:
            return
        if root.lchild is None and root.rchild is None:
            print(root.elem, end='')
        elif root.rchild is None:
            print('('+root.elem+' ', end='')
            self.Preorder_Traversal(root.lchild)
            print(')', end='')
        else:
            print('('+root.elem+' ', end='')
            self.Preorder_Traversal(root.lchild)
            print(' ', end='')
            self.Preorder_Traversal(root.rchild)
            print(')', end='')


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument(
        "mode",
        choices={RECOGNIZER, BESTPARSE, TOTALWEIGHT, ALLPARSE},
        help="execution mode"
    )
    parser.add_argument("grammar", type=Path, help="grammar file in CNF")
    parser.add_argument("sentences", type=Path, help="sentences to be parsed")
    args = parser.parse_args()
    return args


def get_sentences(filename):
    f = open(filename, 'r')
    all_lines = list()
    for line in f.readlines():
        temp = list()
        if line and line[0] != '\n':
            words = re.split(r'[\s]', line.strip())
            for word in words:
                temp.append(word)
            all_lines.append(temp)

    return all_lines


# Get rules from the grammar file
# dictionary of dictionaries
def get_grammar(filename):
    d = {}
    types = ['ROOT']
    f = open(filename, 'r')
    all_lines = list()
    for line in f.readlines():
        if line[0] != '#' and line[0] != ' ' and line[0] != '\n' and line:
            all_lines.append(line)
            words = re.split(r'[\s]', line.strip())
            if words[1] not in types:
                types.append(words[1])

    for type in types:
        d[type] = {}

    for line in all_lines:
        words = re.split(r'[\s]', line.strip())
        temp = []
        for word in words[2:]:
            if word != '' and word != '#':
                temp.append(word)
            if word == '#':
                break
        d[words[1]][tuple(temp)] = float(words[0])
    f.close()
    return types, d


def get_types(rules, *item):
    result = {}
    if len(item) == 1:
        for type in rules:
            if item in rules[type]:
                temp = "(" + type + ' ' + item[0] + ')'
                result[temp] = -math.log(rules[type][item], 2)
    elif len(item) == 2:
        d1 = item[0]
        d2 = item[1]
        for term1 in d1:
            for term2 in d2:
                item1 = re.split(r'[\s]', term1)[0][1:]
                item2 = re.split(r'[\s]', term2)[0][1:]
                target = (item1, item2)
                for type in rules:
                    if target in rules[type]:
                        temp = "(" + type + ' ' + term1 + ' ' + term2 + ')'
                        result[temp] = (d1[term1] + d2[term2])
                        result[temp] -= math.log(rules[type][target], 2)
    return result


def CKY(types, rules, sent):
    N = len(sent)
    D = [[0]*N for i in range(N)]
    for i in range(N):
        for j in range(i+1):
            j = i - j
            if j == i:
                D[i][j] = get_types(rules, sent[i])
            else:
                D[i][j] = {}
                for k in range(i - j):
                    D[i][j].update(get_types(rules, D[j+k][j], D[i][j+k+1]))
    return D[N-1][0]


def get_types_tree(rules, *item):
    result = []
    if len(item) == 1:
        for type in rules:
            if item in rules[type]:
                temp = Node(type, -math.log(rules[type][item], 2))
                result.append(temp)
                temp = Node()

    elif len(item) == 2:
        d1 = item[0]
        d2 = item[1]
        if len(d1) * len(d2) == 0:
            return result
        else:
            for term1 in d1:
                for term2 in d2:
                    item1 = term1.elem
                    item2 = term2.elem
                    target = (item1, item2)
                    for type in rules:
                        if target in rules[type]:
                            weight = term1.weight + term2.weight
                            weight -= math.log(rules[type][target], 2)
                            temp = Node(type, weight, term1, term2)
                            result.append(temp)
                            temp = Node()
    return result


def CKY_Tree(rules, sent):
    N = len(sent)

    D = [[0]*N for i in range(N)]
    for i in range(N):
        for j in range(i+1):
            j = i - j
            if j == i:
                D[i][j] = get_types_tree(rules, sent[i])
                for item in D[i][j]:
                    item.lchild = Node(sent[i])
            else:
                D[i][j] = []
                for k in range(i - j):
                    D[i][j] += get_types_tree(rules, D[j+k][j], D[i][j+k+1])

    return D[N-1][0]


def main():
    args = parse_args()
    sentences = get_sentences(args.sentences)
    types, rules = get_grammar(args.grammar)
    if args.mode == RECOGNIZER:
        for sent in sentences:
            print(not CKY_Tree(rules, sent) == [])

    if args.mode == BESTPARSE:
        for sent in sentences:
            D = CKY_Tree(rules, sent)
            if D:
                weight = []
                for item in D:
                    weight.append(item.weight)
                minweight = min(weight)
                minparse = D[weight.index(minweight)]
                print("%.3f\t" % minweight, end='')
                minparse.Preorder_Traversal(minparse)
                print()
            else:
                print('-'+'\t'+'NOPARSE')

    if args.mode == TOTALWEIGHT:
        for sent in sentences:
            D = CKY_Tree(rules, sent)
            if D:
                P = 0
                for item in D:
                    P += 2**(-item.weight)
                print("%.3f" % -math.log(P, 2))
            else:
                print('-')

    if args.mode == ALLPARSE:
        for sent in sentences:
            D = CKY_Tree(rules, sent)
            if D:
                for item in D:
                    print(item.weight, end='')
                    item.Preorder_Traversal(item)
                    print()
                print()
            else:
                print('-', '\t', 'NOPARSE')


if __name__ == "__main__":
    '''
    args = parse_args()
    sentences = get_sentences(args.sentences)
    types, rules = get_grammar(args.grammar)
    item = get_types_tree(rules, 'book')
    for i in item:
        print(i.elem)'''
    main()
